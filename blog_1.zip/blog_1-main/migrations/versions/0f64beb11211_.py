"""empty message

Revision ID: 0f64beb11211
Revises: 08bac9e4edb3, ae346256b650
Create Date: 2025-08-19 13:36:54.121344

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0f64beb11211'
down_revision = ('08bac9e4edb3', 'ae346256b650')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
