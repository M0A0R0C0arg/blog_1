app = Flask(__name__)
app.config['SECRET_KEY'] = 'mi_secreto'
# mas variables